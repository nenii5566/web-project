<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'food1';

// $host = 'sql308.infinityfree.com';
// $user = 'if0_37714377';
// $password = 'Nensi123';
// $dbname = 'if0_37714377_food';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
