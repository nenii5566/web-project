<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM register WHERE email='$email'");
    $sql = "INSERT INTO login1 (email, password) VALUES ('$email', '$password')";
    $conn->query($sql);
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            include 'index.php';
        } else {
            echo "Incorrect password!";
        }
    } else {
        echo "Email not registered!";
    }
}
?>
