<?php include 'db.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Store by D&N</title>
  <link rel="icon" href="image/favicon.PNG">


    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS File -->
    <link rel="stylesheet" href="style1.css">

    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>

    <script>
        function onHover(button, hover) {
            if (hover) {
                button.style.backgroundColor = "green";  
                button.style.color = "white";
            } else {
                button.style.backgroundColor = "white";
                button.style.color = "green";  
            }
        }
        function onHover1(button, hover) {
            if (hover) {
                button.style.backgroundColor = "white";  
                button.style.color = "green";
            } else {
                button.style.backgroundColor = "green";
                button.style.color = "white";  
            }
        }
    </script>

</head>
<body>

    <!-- Header Section -->
    <header class="header">
        <a href="#" class="logo">  <i class="fa fa-shopping-basket"></i> Grocery </a>
        <nav class="navbar">
            <a href="#home">home</a>
            <a href="#features">features</a>
            <a href="#products">products</a>
            <a href="#categories">categories</a>
            <a href="#review">reviews</a>
            <a href="#blogs">blogs</a>
        </nav>

        <div class="icons" style="width: 300px;">
            <div class="fa fa-bars" id="menu-btn"></div>
            <div class="fa fa-search" id="search-btn"></div>
            <div class="fa fa-shopping-cart" id="cart-btn"></div>
            <a href="login.html">
                <button id="login-btn" style="width: 90px; height: 4.5rem; color: var(--green);
                background-color: white; border: 1.5px solid var(--green); font-weight: bolder; border-radius: 5px;"
                onmouseover="onHover(this, true)" 
                onmouseout="onHover(this, false)">
                    Login
                </button>
            </a>
            <a href="register.html">
                <button id="register-btn" style="width: 100px; height: 4.5rem; color: white;
                background-color: var(--green); border-radius: 5px; border: 1.5px solid var(--green);"
                onmouseover="onHover1(this, true)" 
                onmouseout="onHover1(this, false)">
                    Register
                </button>
            </a>
        </div>

        <form action="#" class="search-form">
            <input type="search" id="search-box" placeholder="Search here...">
            <label for="search-box" class="fa fa-search"></label>
        </form>
    
        <div class="shopping-cart">
            <div class="box">
                <i class="fa fa-trash" aria-label="Remove item"></i>
                <img src="image/cart-img-1.png" alt="Watermelon">
                <div class="content">
                    <h3>Watermelon</h3>
                    <span class="price">$5.99</span>
                    <span class="quantity">Qty: 1</span>
                </div>
            </div>
            <div class="box">
                <i class="fa fa-trash" aria-label="Remove item"></i>
                <img src="image/cart-img-2.png" alt="Onion">
                <div class="content">
                    <h3>Onion</h3>
                    <span class="price">$9.99</span>
                    <span class="quantity">Qty: 1</span>
                </div>
            </div>
            <div class="box">
                <i class="fa fa-trash" aria-label="Remove item"></i>
                <img src="image/cart-img-3.png" alt="Chicken">
                <div class="content">
                    <h3>Chicken</h3>
                    <span class="price">$5.99</span>
                    <span class="quantity">Qty: 1</span>
                </div>
            </div>
            <div class="total"> Total: $18.97 </div>
            <a href="#" class="btn">Checkout</a>
        </div>

    </header>
    <!-- Header Section -->

    <!-- Banner Section -->
    <section class="home" id="home">
        <div class="content">
            <h3>Fresh and <span>Organic</span> Products For You</h3>
            <p>This Website is Designed by <span> Dhwani</span> and <span>Nensi</span> . Hope you all like it!!!</p>
            <a href="#" class="btn">Shop Now</a>
        </div>
    </section>
    <!-- Banner Section -->

    <!-- Features Section -->
    <section class="features" id="features">
        <h1 class="heading"> our <span>features</span> </h1>
        <div class="box-container">
            <div class="box">
                <img src="image/feature-img-1.png" alt="Feature 1">
                <h3>fresh and organic</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                <a href="#" class="btn">read more</a>
            </div>
            <div class="box">
                <img src="image/feature-img-2.png" alt="Feature 2">
                <h3>fresh and organic</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                <a href="#" class="btn">read more</a>
            </div>
            <div class="box">
                <img src="image/feature-img-3.png" alt="Feature 3">
                <h3>fresh and organic</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
                <a href="#" class="btn">read more</a>
            </div>
        </div>
    </section>
    <!-- Features Section -->

    <!-- Products Section -->
    <section class="products" id="products">
        <h1 class="heading"> our <span>products</span> </h1>
        <div class="swiper product-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide box">
                    <img src="image/product-1.png" alt="Product 1">
                    <h1>fresh oranges</h1>
                    <div class="price"> $12.99/- - $15.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-2.png" alt="Product 2">
                    <h1>fresh onions</h1>
                    <div class="price"> $20.99/- - $23.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-3.png" alt="Product 3">
                    <h1>fresh meat</h1>
                    <div class="price"> $14.99/- - $15.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-4.png" alt="Product 4">
                    <h1>fresh cabbages</h1>
                    <div class="price"> $7.99/- - $10.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
            </div>
        </div>

        <div class="swiper product-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide box">
                    <img src="image/product-5.png" alt="Product 5">
                    <h1>fresh potatoes</h1>
                    <div class="price"> $10.99/- - $15.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-6.png" alt="Product 6">
                    <h1>fresh avocados</h1>
                    <div class="price"> $20.99/- - $30.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-7.png" alt="Product 7">
                    <h1>fresh carrots</h1>
                    <div class="price"> $14.99/- - $15.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
                <div class="swiper-slide box">
                    <img src="image/product-8.png" alt="Product 8">
                    <h1>fresh lemons</h1>
                    <div class="price"> $7.99/- - $10.99/-</div>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <a href="#" class="btn">add to cart</a>
                </div>
            </div>
        </div>
    </section>
    <!-- Products Section -->

    <!-- Categories Section -->
    <section class="categories" id="categories">
        <h1 class="heading">Product <span>Categories</span></h1>
        <div class="box-container">
            <div class="box">
                <img src="image/cat-1.png" alt="Vegetables">
                <h3>Vegetables</h3>
                <p>Upto 45% off</p>
                <a href="#" class="btn">Shop Now</a>
            </div>
            <div class="box">
                <img src="image/cat-2.png" alt="Fresh Fruits">
                <h3>Fresh Fruits</h3>
                <p>Upto 45% off</p>
                <a href="#" class="btn">Shop Now</a>
            </div>
            <div class="box">
                <img src="image/cat-3.png" alt="Dairy Products">
                <h3>Dairy Products</h3>
                <p>Upto 45% off</p>
                <a href="#" class="btn">Shop Now</a>
            </div>
            <div class="box">
                <img src="image/cat-4.png" alt="Fresh Meat">
                <h3>Fresh Meat</h3>
                <p>Upto 45% off</p>
                <a href="#" class="btn">Shop Now</a>
            </div>
        </div>
    </section>
    <!-- Categories Section -->

    <!-- Review Section -->
    <section class="review" id="review">
        <h1 class="heading">Customer's <span>Review</span></h1>
        <div class="swiper-container review-slider">
            <div class="swiper-wrapper">
                <div class="swiper-slide box">
                    <img src="image/pic-1.png" alt="Harshil">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae quasi voluptate, incidunt nihil amet dolore! Ab consequatur alias adipisci tempora?</p>
                    <h3>Jenil</h3>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <img src="image/pic-2.png" alt="Harshil">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae quasi voluptate, incidunt nihil amet dolore! Ab consequatur alias adipisci tempora?</p>
                    <h3>Dhwanii</h3>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <img src="image/pic-3.png" alt="Harshil">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae quasi voluptate, incidunt nihil amet dolore! Ab consequatur alias adipisci tempora?</p>
                    <h3>Hitarth</h3>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                </div>
                <div class="swiper-slide box">
                    <img src="image/pic-4.png" alt="Harshil">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae quasi voluptate, incidunt nihil amet dolore! Ab consequatur alias adipisci tempora?</p>
                    <h3>Nensi</h3>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                </div>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
            <!-- Add Navigation -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </section>
    
    <!-- Review Section -->


     <!--Blog section-->

     <section class="blogs" id="blogs">
        <h1 class="heading"> Our <span> BLogs</span></h1>
        <div class="box-container">
            <div class="box">
                <img src="image/blog-1.jpg" alt="">
                <div class="content">
                    <div class="icons">
                        <a href="#"> <i class="fa fa-user"></i> By User</a>
                        <a href="#"> <i class="fa fa-calendar"></i> 2nd August, 2024</a>
                    </div>
                    <h3>Fresh and Organic Vegetables and Fruits</h3>
                    <p>Fruits just make life better, organic fruits make life even better!!! </p>
                    <a href="#" class="btn">read more</a>
                </div>
            </div>

            <div class="box-container">
                <div class="box">
                    <img src="image/blog-2.jpg" alt="">
                    <div class="content">
                        <div class="icons">
                            <a href="#"> <i class="fa fa-user"></i> By User</a>
                            <a href="#"> <i class="fa fa-calendar"></i> 2nd August, 2024</a>
                        </div>
                        <h3>Fresh and Organic Vegetables and Fruits</h3>
                        <p>Buying fresh fruits and vegetables online in today's fast-paced world,the search for fresh and nutritious fruits and vegetables. </p>
                        <a href="#" class="btn">read more</a>
                    </div>
                </div>

                 </div>

      </section>

      <!--Blog section-->


        <!--Footer section-->

        <section class="footer">
            <div class="box-container">
                <div class="box">
                    <h3> Groco <i class="fa fa-shopping-basket"></i></h3>
                    <p>Feel free to follow us on our Social Media Handlers all the links are given below.</p>
                    <div class="share">
                        <a href="#" class="fa fa-facebook"></a>
                        <a href="#" class="fa fa-instagram"></a>
                        <a href="#" class="fa fa-twitter"></a>
                        <a href="#" class="fa fa-linkedin"></a>               
                     </div>
                </div>
                <div class="box">
                    <h3>Contact info</h3>
                    <a href="#" class="fa fa-links"> <i class="fa fa-phone"></i>+91 9876543210</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-phone"></i>+91 9123456780</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-envelope"></i>info@example.com</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-map-marker"></i>Anand, Gujarat, India</a>
                 </div>
    
                 <div class="box">
                    <h3>Quick links</h3>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>Home</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>Features</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>products</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>categories</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>review</a>
                    <a href="#" class="fa fa-links"> <i class="fa fa-arrow-right"></i>blogs</a>
                    
                    </div>
                    <div class="box">
                        <h3>News Letter</h3>
                        <p>subscribe for latest update</p>
                        <input type="email" placeholder="your email" class="email">
                        <input type="submit" value="subscribe" class="btn">
                        <img src="image/payment.png" alt="">
                        </div>
    
                    </div>
                    <div class="credit"> created by <span>Dhwani and Nensi</span>  |  all rights reserved</div>
          </section>
    
            

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- Custom JS -->
    <script src="script.js"></script>


    
</body>
</html>
