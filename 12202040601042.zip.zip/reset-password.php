<?php
include 'db.php';

$token = $_GET['token'];
$result = $conn->query("SELECT * FROM register WHERE token='$token' AND token_expiration > NOW()");

if ($result->num_rows == 1) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
        $conn->query("UPDATE register SET password='$new_password', token=NULL, token_expiration=NULL WHERE token='$token'");
        echo "Password reset successfully!";
    }
} else {
    echo "Invalid or expired token!";
}
?>
