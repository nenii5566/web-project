<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $result = $conn->query("SELECT * FROM register WHERE email='$email'");
    
    if ($result->num_rows == 1) {
        $token = bin2hex(random_bytes(50));
        $conn->query("UPDATE register SET token='$token', token_expiration=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email='$email'");

        // Replace "http://yourdomain.com" with your actual domain
        $resetLink = "Slocalhost/grossary/send-reset-link.php?token=$token";
        $subject = "Password Reset";
        $message = "Click this link to reset your password: $resetLink";
        $headers = "From: no-reply@yourdomain.com";

        if (mail($email, $subject, $message, $headers)) {
            echo "A reset link has been sent to your email.";
        } else {
            echo "Error sending email.";
        }
    } else {
        echo "Email not found!";
    }
}
?>
<p>send-reset-link</p>